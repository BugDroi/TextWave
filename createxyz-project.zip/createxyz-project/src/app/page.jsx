"use client";
import React from "react";
import NewComponent from "../components/new-component";

function MainComponent() {
  const [messages, setMessages] = React.useState([]);
  const [message, setMessage] = React.useState("");
  const [username, setUsername] = React.useState("");
  const [isOneOnOne, setIsOneOnOne] = React.useState(false);
  const [recipient, setRecipient] = React.useState("");
  const [users, setUsers] = React.useState([]);
  const [showUserList, setShowUserList] = React.useState(false);

  React.useEffect(() => {
    const storedUsername = localStorage.getItem("username");
    if (storedUsername) {
      setUsername(storedUsername);
    } else {
      const newUsername = prompt("ユーザー名を入力してください：");
      if (newUsername) {
        setUsername(newUsername);
        localStorage.setItem("username", newUsername);
      }
    }
    fetchMessages();
    fetchUsers();
    const interval = setInterval(fetchMessages, 1000);
    return () => clearInterval(interval);
  }, []);

  const fetchMessages = async () => {
    try {
      const response = await fetch("/api/db/messages-95", {
        method: "POST",
        body: JSON.stringify({
          query: "SELECT * FROM `messages` ORDER BY `timestamp` ASC",
        }),
        headers: {
          "Content-Type": "application/json",
        },
      });
      const data = await response.json();
      setMessages(data);
    } catch (error) {
      console.error("Error fetching messages:", error);
    }
  };

  const fetchUsers = async () => {
    try {
      const response = await fetch("/api/db/messages-95", {
        method: "POST",
        body: JSON.stringify({
          query: "SELECT DISTINCT username FROM `messages`",
        }),
        headers: {
          "Content-Type": "application/json",
        },
      });
      const userList = await response.json();
      setUsers(userList.map((user) => user.username));
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  const handleSend = async () => {
    if (message && username) {
      if (message.trim() === "-d") {
        await handleClearHistory();
      } else if (message.trim().endsWith("-u")) {
        const newUsername = prompt("新しいユーザー名を入力してください：");
        if (newUsername) {
          setUsername(newUsername);
          localStorage.setItem("username", newUsername);
        }
      } else if (message.trim() === "-i") {
        const lastMessage = messages[messages.length - 1];
        if (lastMessage) {
          await generateImage(lastMessage.text);
        } else {
          alert("前のメッセージがありません。");
        }
      } else {
        const newMessage = {
          text: message,
          username,
          timestamp: new Date().toISOString(),
          recipient,
        };
        await fetch("/api/db/messages-95", {
          method: "POST",
          body: JSON.stringify({
            query:
              "INSERT INTO `messages` (text, type, timestamp, username, recipient) VALUES (?, ?, ?, ?, ?)",
            values: [
              newMessage.text,
              "sent",
              newMessage.timestamp,
              newMessage.username,
              recipient,
            ],
          }),
          headers: {
            "Content-Type": "application/json",
          },
        });
        setMessages((prevMessages) => [...prevMessages, newMessage]);

        if (message.trim().endsWith("-c")) {
          fetchChatGPTResponse(message.slice(0, -2));
        }
      }
      setMessage("");
    }
  };

  const generateImage = async (prompt) => {
    try {
      const response = await fetch(
        `/integrations/stable-diffusion-v-3/?prompt=${encodeURIComponent(
          prompt
        )}`
      );
      const data = await response.json();

      if (data.data && data.data.length > 0) {
        const imageUrl = data.data[0];
        const newMessage = {
          text: `Generated image: ${imageUrl}`,
          username: "Stable Diffusion",
          timestamp: new Date().toISOString(),
          isImage: true,
        };

        await fetch("/api/db/messages-95", {
          method: "POST",
          body: JSON.stringify({
            query:
              "INSERT INTO `messages` (text, type, timestamp, username) VALUES (?, ?, ?, ?)",
            values: [
              newMessage.text,
              "received",
              newMessage.timestamp,
              newMessage.username,
            ],
          }),
          headers: {
            "Content-Type": "application/json",
          },
        });

        setMessages((prevMessages) => [...prevMessages, newMessage]);
      } else {
        console.error("No image data received from Stable Diffusion");
      }
    } catch (error) {
      console.error("Error generating image:", error);
    }
  };

  const handleClearHistory = async () => {
    try {
      await fetch("/api/db/messages-95", {
        method: "POST",
        body: JSON.stringify({
          query: "DELETE FROM `messages`",
        }),
        headers: {
          "Content-Type": "application/json",
        },
      });
      setMessages([]);
    } catch (error) {
      console.error("Error clearing history:", error);
    }
  };

  const toggleOneOnOneMode = () => {
    setIsOneOnOne(!isOneOnOne);
    if (!isOneOnOne) {
      const recipientName = prompt(
        "チャットの相手のユーザー名を入力してください："
      );
      setRecipient(recipientName);
    } else {
      setRecipient("");
    }
  };

  const toggleUserList = () => {
    setShowUserList(!showUserList);
  };

  return (
    <div className="flex flex-col items-center p-8 bg-white min-h-screen">
      <div className="w-full max-w-3xl bg-blue-50 shadow-xl rounded-xl mb-4 flex flex-col h-full">
        <div className="p-4 bg-blue-100 w-full flex justify-between sticky top-0 z-10">
          <div className="flex items-center">
            <h1 className="text-3xl font-extrabold font-sans text-blue-600">
              TextWave -β
            </h1>
            {isOneOnOne && (
              <span className="ml-4 text-sm text-gray-700">
                DMモード: {recipient}
              </span>
            )}
          </div>
          <div className="flex items-center space-x-4">
            <NewComponent onClick={toggleUserList} disabled={false}>
              <span className="text-lg">参加者一覧</span>
            </NewComponent>
            <NewComponent onClick={toggleOneOnOneMode} disabled={false}>
              <span className="text-lg">
                {isOneOnOne ? "グループモード" : "DMモード"}
              </span>
            </NewComponent>
          </div>
        </div>
        {showUserList && (
          <div className="p-4 bg-white border-b border-gray-200">
            <h2 className="text-lg font-semibold mb-2">参加者一覧</h2>
            <table className="w-full">
              <thead>
                <tr>
                  <th className="text-left">ユーザー名</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user, index) => (
                  <tr key={index}>
                    <td>{user}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <div className="flex flex-col p-8 flex-grow overflow-y-auto">
          <div className="flex flex-col space-y-4">
            {messages
              .filter(
                (msg) =>
                  !isOneOnOne ||
                  msg.recipient === username ||
                  msg.username === username
              )
              .map((msg, index) => (
                <div key={index} className="flex flex-col">
                  <div
                    className={`p-4 rounded-lg shadow-lg ${
                      msg.username === username
                        ? "bg-blue-400 text-white self-end"
                        : isOneOnOne && msg.recipient === username
                        ? "bg-[#c5a880] text-white self-start"
                        : "bg-blue-100 text-blue-900 self-start"
                    }`}
                  >
                    <div className="flex justify-between items-center mb-1">
                      <p className="text-xs font-bold uppercase">
                        {msg.username}
                      </p>
                      {msg.recipient && (
                        <span className="text-xs bg-gray-200 text-gray-700 px-1 rounded">
                          DM
                        </span>
                      )}
                    </div>
                    {msg.isImage ? (
                      <img
                        src={msg.text.split(": ")[1]}
                        alt="Generated"
                        className="max-w-full h-auto rounded"
                      />
                    ) : (
                      <p className="text-sm">{msg.text}</p>
                    )}
                  </div>
                  <p
                    className={`text-xs text-gray-500 mt-1 ${
                      msg.username === username ? "self-end" : "self-start"
                    }`}
                  >
                    {new Date(msg.timestamp).toLocaleTimeString()}
                  </p>
                </div>
              ))}
          </div>
        </div>
        <div className="p-4 bg-blue-100 w-full flex justify-center sticky bottom-0 z-10">
          <input
            type="text"
            className="flex-grow border border-blue-600 p-4 rounded-l-lg text-blue-900 focus:outline-none focus:ring-2 focus:ring-blue-400"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="メッセージを入力"
            name="message"
          />
          <NewComponent onClick={handleSend} disabled={!username}>
            送信
          </NewComponent>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;