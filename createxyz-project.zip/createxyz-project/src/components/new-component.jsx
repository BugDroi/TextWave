"use client";
import React from "react";

function NewComponent({ onClick, disabled, children }) {
  return (
    <button
      onClick={onClick}
      className="bg-blue-600 text-white font-semibold p-4 rounded-r-lg hover:bg-blue-700 transition-all duration-300"
      disabled={disabled}
    >
      {children}
    </button>
  );
}

function NewComponentStory() {
  return (
    <div>
      <NewComponent onClick={() => {}} disabled={false}>
        このページを削除
      </NewComponent>
      <NewComponent onClick={() => {}} disabled={true}>
        このページを削除
      </NewComponent>
    </div>
  );
}

export default NewComponent;